# Fejlesztés

Gyors fejlesztői környezethez jutás:

```
cd app
docker-compose -f docker-compose/dev.yml up
bin/console d:s:c
bin/console s:r
```

Itt az app:

http://localhost:8000
